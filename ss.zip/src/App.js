// import React from 'react';
import React, {Component} from 'react';
import './App.css';

import Person from './Person/Person';

// function App() {
//   return (
//     <div className="App">
//       <Person name="gega" age="29"/>
//       <Person name="gonz" age="39">Hobby: Coding!</Person>
//     </div>
//   );
// }
class App extends Component{
  state={
    Person:[
      {name: 'gega', age:34},
      {name: 'sda', age:32},
      {name: 'gonz', age:39}
    ]
  }
changeName = (newName)=>{
  console.log('hi')
  this.setState({
    Person:[
      {name: newName, age:34},
      {name: 'lle', age:34},
      {name: 'ase', age:39}
    ]
  })
}


  render(){
    const items= [];
    for(const [index,value] of this.state.Person.entries()){
      if(value.name === 'gega' || value.name === "Ahmad" || value.name === 'Dali')
        items.push(
          <Person 
            key={index} 
            name={value.name} 
            // onclickHandler={this.changeName.bind(this, 'Ahmad')} 
            onclickHandler={()=>{this.changeName('Ahmad')}} 
            age={value.age}>
              Hobby: Gaming
          </Person>)
      else items.push(<Person key={index} name={value.name} age={value.age}/>)
    }
    return(
      <div className="App">
      {items}
      {/*<button onClick={this.changeName.bind(this, 'Dali')}>click</button>*/}
      <button onClick={()=>{this.changeName('Dali')}}>click</button>

      {/* {this.state.Person.map((value, index)=>{
        return <Person key={index} name={value.name} age={value.age}/>
      })} */}
       {/* <Person name={this.state.Person[0].name} age={this.state.Person[0].age}/>
       <Person name={this.state.Person[1].name} age={this.state.Person[1].age}>Hobby: Coding!</Person> */}
     </div>
    );
  }
}
export default App;
